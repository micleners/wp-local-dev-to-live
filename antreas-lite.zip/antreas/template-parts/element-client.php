<div class="client">
	<?php the_post_thumbnail( 'portfolio', array( 'class' => 'client-image' ) ); ?>	
	<?php antreas_edit(); ?>
</div>
