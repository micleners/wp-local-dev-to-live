Thanks for downloading this theme!

This theme is meant to work hand in hand with the CPO Companion plugin.
The plugin is very light, and you will need to install it in order to
manage the main slider, homepage features, as well as the portfolio:
https://wordpress.org/plugins/cpo-companion/

If you have any questions regarding its usage, you can read the
quickstart guide at the following URL:
https://docs.machothemes.com/

Antreas WordPress Theme, Copyright (C) 2018, Macho Themes
Antreas is distributed under the terms of the GNU GPL

BUNDLED RESOURCES
All resources bundled with this theme are licensed or compatible
with the GPLv2. Following is a list of all of them:

Font Awesome - https://fontawesome.com/v4.7.0/
License: https://fontawesome.com/v4.7.0/license/
Copyright: Dave Gandy

Jquery Cycle2 - http://jquery.malsup.com/cycle2/
License: Dual licensed under the MIT and GPL licenses.
Copyright: M. Alsup

HTML5 Shiv - https://github.com/aFarkas/html5shiv
License: Dual licensed under the MIT and GPL licenses.
Copyright: @afarkas @jdalton @jon_neal @rem

Magnific Popup - http://dimsemenov.com/plugins/magnific-popup/
License: MIT License
Copyright: Stephane Caron

Selectize - https://github.com/selectize/selectize.js
License: http://www.apache.org/licenses/LICENSE-2.0
Copyright: Brian Reavis & Contributors

Theme Screenshot Image
Photo by Joel Filipe
https://stocksnap.io/photo/YEWW2351JM